@echo off
:start
cls
echo DeHelper by DedOKk
echo.
echo.
echo :: Taskkillz
echo.
echo 1. Taskkill by name of process 
echo.
echo 2. Task manager in .bat file
echo.
echo.
echo :: Start apps
echo.
echo 3. Start by way to file
echo.
echo.
echo :: Re-start explorer.exe (If it closed by virus or smth)
echo.
echo 4. Re-start explorer.exe
echo.
echo.
echo.
echo.
set /p var=Select command (1-4):
if %var%==1 goto tskk
if %var%==2 goto tskm
if %var%==3 goto stbw
if %var%==4 goto rse.e
:tskk
cls
set /p task=Your task to kill:
taskkill /f /im %task%
echo.
echo.
echo ===================================
echo    Press any key to return to menu
pause >nul
goto start
:tskm
cls
tasklist /NH /FO TABLE /FI "STATUS eq running"
echo.
echo.
echo ===================================
echo    Press any key to return to menu
pause >nul
goto start
:stbw
cls
set /p app=Way to your app / App name:
start %app%
echo.
echo.
echo ===================================
echo    Press any key to return to menu
pause >nul
goto start
:rse.e
taskkill /f /im explorer.exe
timeout /t 1 /nobreak >nul
start explorer.exe
goto start
